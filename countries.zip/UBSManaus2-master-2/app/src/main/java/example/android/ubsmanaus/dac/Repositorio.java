package example.android.ubsmanaus.dac;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

import example.android.ubsmanaus.Model.Ubs;

public class Repositorio {

    private SQLHelper helper;
    private SQLiteDatabase db;

    public Repositorio(Context ctx){
        helper = new SQLHelper(ctx);
    }

    public long inserir(Ubs ubs){
        db = helper.getReadableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(SQLHelper.COLUNA_NAME, ubs.name);
        cv.put(SQLHelper.COLUNA_ALPHA2CODE, ubs.alpha2Code);
        cv.put(SQLHelper.COLUNA_CAPITAL, ubs.capital);
        cv.put(SQLHelper.COLUNA_REGION, ubs.region);
        cv.put(SQLHelper.COLUNA_SUBREGION, ubs.subregion);
        cv.put(SQLHelper.COLUNA_POPULATION, ubs.population);
        cv.put(SQLHelper.COLUNA_AREA, ubs.area);
        cv.put(SQLHelper.COLUNA_NUMERICCODE, ubs.numericCode);
        cv.put(SQLHelper.COLUNA_RELEVANCE, ubs.relevance);
        long id = db.insert(SQLHelper.TABELA_CON, null, cv);

        if(id != -1){
            ubs.id = id;
        }
        db.close();
        return id;
    }

    public void excluirAll(){
        db = helper.getWritableDatabase();
        db.delete(SQLHelper.TABELA_CON, null, null);
        db.close();
    }

    public List<Ubs> listarUbs() {
        String sql = "SELECT * FROM " + SQLHelper.TABELA_CON;
        db = helper.getReadableDatabase();
        Cursor cursor = db.rawQuery(sql, null);
        List<Ubs> list = new ArrayList();

        while (cursor.moveToNext()) {
            String name = cursor.getString(
                    cursor.getColumnIndex(SQLHelper.COLUNA_NAME)
            );
            String alpha2Code = cursor.getString(
                    cursor.getColumnIndex(SQLHelper.COLUNA_ALPHA2CODE)
            );
            String capital = cursor.getString(
                    cursor.getColumnIndex(SQLHelper.COLUNA_CAPITAL)
            );
            String region = cursor.getString(
                    cursor.getColumnIndex(SQLHelper.COLUNA_REGION)
            );
            String subregion = cursor.getString(
                    cursor.getColumnIndex(SQLHelper.COLUNA_SUBREGION)
            );
            String population = cursor.getString(
                    cursor.getColumnIndex(SQLHelper.COLUNA_POPULATION)
            );
            String area = cursor.getString(
                    cursor.getColumnIndex(SQLHelper.COLUNA_AREA)
            );
            String numericCode = cursor.getString(
                    cursor.getColumnIndex(SQLHelper.COLUNA_NUMERICCODE)
            );
            String relevance = cursor.getString(
                    cursor.getColumnIndex(
                            SQLHelper.COLUNA_RELEVANCE)
            );

            Ubs ubs = new Ubs(name, alpha2Code, capital, region, subregion, population, area, numericCode, relevance);
            list.add(ubs);
        }
        cursor.close();
        return list;
    }

}