Aplicativo base para realização do codelab abaixo:
https://codelabs-preview.appspot.com/?file_id=156JKx6Rl2LKF7K9Q57QgY_aT3LityJp9vS_U-Vqzgzw#2
Que foi apresentado na disciplina de Sistemas distribuidos - IComp.
